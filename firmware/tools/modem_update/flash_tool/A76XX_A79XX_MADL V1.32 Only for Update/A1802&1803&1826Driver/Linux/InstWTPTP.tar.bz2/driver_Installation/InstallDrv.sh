#!/bin/bash

function Init_ModuleName()  # Never useful anymore
{
    Main_Ver=$(echo ${Kernel_Ver:0:1})
    Sub_Ver=$(echo ${Kernel_Ver:2:1})
    Patch_Ver=$(echo ${Kernel_Ver:4})
    echo $Kernel_Info > null
    echo ${Main_Ver} > null
    echo ${Sub_Ver} > null
    echo ${Patch_Ver} > null

    LargeVer=0
    if [ $Main_Ver -ge 2 ]; then
    {
        if [ $Sub_Ver -ge 6 ]; then
        {
            if [ $Patch_Ver -ge 35 ]; then
            {
                #echo "Kernel Ver is larger than 2.6.35"
                $LargeVer = 1
            }
            fi
        }
        fi
    }
    fi

    if [ $LargeVer -eq 1 ]; then
    {
        cp -f ./wtptp_largever.ko /lib/modules/"$Kernel_Info"/kernel/drivers/misc/wtptp.ko
    }
    else
    {
        cp -f ./wtptp_smallver.ko /lib/modules/"$Kernel_Info"/kernel/drivers/misc/wtptp.ko
    }
    fi
}

function PrepareInst()
{
    if [ -e wtptp_"$Kernel_Ver"_"$Processor_Ver".ko ]; then
    {
        #echo ./wtptp_"$Kernel_Info".ko /lib/modules/"$Kernel_Info"/kernel/drivers/misc/wtptp.ko
        cp -f ./wtptp_"$Kernel_Ver"_"$Processor_Ver".ko /lib/modules/"$Kernel_Info"/kernel/drivers/misc/wtptp.ko
    }
    else
    {
        echo "WTPTP driver does NOT support current Kernel!"
        exit 1
    }
    fi
}

function Set_Env()
{
    echo "Add the module to /etc/modules..."
    echo "wtptp" >> /etc/modules
}

function Clean_Env()
{
    echo "Remove the module from /etc/modules..."

    sed -e '/wtptp/d' /etc/modules > /etc/modules.new
    cp /etc/modules.new /etc/modules
    rm /etc/modules.new
}

function main()
{
    OPTIONS="Install Uninstall Quit"
    echo "========================================================================"
    echo " NOTICE! This installation needs the permission of root!"
    echo " Please input the one of [1 2 3] for install or uninstall WTPTP module:"
    echo "========================================================================"
    
    select opt in $OPTIONS; do
    {
        if [ "$opt" = "Install" ]; then
        {
            echo "Installing WTPTP module..."
            PrepareInst
            insmod /lib/modules/"$Kernel_Info"/kernel/drivers/misc/wtptp.ko
            Set_Env
            break
        }
        elif [ "$opt" = "Uninstall" ]; then
        {
            echo "Uninstalling WTPTP module..."
            rmmod /lib/modules/"$Kernel_Info"/kernel/drivers/misc/wtptp.ko
            Clean_Env
            break
        }
        elif [ "$opt" = "Quit" ]; then
        {
            echo "Quit the installation!"
            break
        }
        else
        {
            echo "You input a bad option! Please input the one of [1 2 3]"
            continue
        }
        fi
    }
    done
}
    
Kernel_Info=$(uname -r)
Processor_Info=$(uname -p)   
Kernel_Ver=$(echo "${Kernel_Info%%-*}")
Processor_Ver=$(echo "${Processor_Info}")
echo ${Kernel_Ver}
echo ${Processor_Ver}

main
exit 0
